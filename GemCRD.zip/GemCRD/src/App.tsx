// src/App.tsx

import React from 'react';
import { InventoryProvider } from './context/InventoryContext';
import InventoryDisplay from './components/InventoryDisplay';
import ReservationForm from './components/ReservationForm';
import './App.css';

function App() {
  return (
    <InventoryProvider>
      <div className="App">
        <header className="App-header">
          <h1>Vehicle Reservation System</h1>
          <InventoryDisplay />
          <ReservationForm />
        </header>
      </div>
    </InventoryProvider>
  );
}

export default App;
