// src/components/InventoryDisplay.tsx

import React from 'react';
import { useInventory } from '../context/InventoryContext';
import { VEHICLE_TYPES } from '../types';

const InventoryDisplay = () => {
  const { inventory } = useInventory();

  return (
    <div
      style={{
        marginBottom: '20px',
        padding: '10px',
        border: '1px solid #ccc',
      }}
    >
      <h2>Available Vehicles</h2>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {VEHICLE_TYPES.map((type) => (
          <li key={type} data-testid={`inventory-${type}`}>
            {type.toUpperCase()}: <strong>{inventory[type]}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default InventoryDisplay;
