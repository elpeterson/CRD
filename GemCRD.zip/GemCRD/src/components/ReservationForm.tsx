// src/components/ReservationForm.tsx

import React, { useState, FormEvent } from 'react';
import { useInventory } from '../context/InventoryContext';
import { VehicleType, VEHICLE_TYPES } from '../types';

const ReservationForm = () => {
  const { makeReservation } = useInventory();
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType>(
    VEHICLE_TYPES[0]
  );
  const [days, setDays] = useState<number>(1);
  const [message, setMessage] = useState<string>('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setMessage('');

    if (days <= 0) {
      setMessage('Error: Number of days must be greater than 0.');
      return;
    }

    try {
      makeReservation(selectedVehicle);
      setMessage(
        `Success! Reserved a ${selectedVehicle.toUpperCase()} for ${days} day(s).`
      );
    } catch (error) {
      if (error instanceof Error) {
        setMessage(`Error: ${error.message}`);
      } else {
        setMessage('An unknown error occurred.');
      }
    }
  };

  return (
    <div style={{ padding: '10px', border: '1px solid #ccc' }}>
      <h2>Create a Reservation</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="vehicleType">Vehicle Type: </label>
          <select
            id="vehicleType"
            value={selectedVehicle}
            onChange={(e) => setSelectedVehicle(e.target.value as VehicleType)}
          >
            {VEHICLE_TYPES.map((type) => (
              <option key={type} value={type}>
                {type.toUpperCase()}
              </option>
            ))}
          </select>
        </div>
        <div style={{ marginTop: '10px' }}>
          <label htmlFor="days">Number of Days: </label>
          <input
            id="days"
            type="number"
            value={days}
            onChange={(e) => setDays(parseInt(e.target.value, 10))}
            min="1"
          />
        </div>
        <button type="submit" style={{ marginTop: '15px' }}>
          Create Reservation
        </button>
      </form>
      {message && (
        <p role="alert" style={{ marginTop: '15px', fontWeight: 'bold' }}>
          {message}
        </p>
      )}
    </div>
  );
};

export default ReservationForm;
