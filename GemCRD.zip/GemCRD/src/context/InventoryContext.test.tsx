// src/context/InventoryContext.test.tsx

import { render, screen, fireEvent, act } from '@testing-library/react';
import { InventoryProvider, useInventory } from './InventoryContext';
import { ReactNode } from 'react';

// A helper test component to access context values
const TestComponent = () => {
  const { inventory, makeReservation } = useInventory();
  return (
    <div>
      <div data-testid="sedan-count">{inventory.sedan}</div>
      <div data-testid="suv-count">{inventory.suv}</div>
      <div data-testid="van-count">{inventory.van}</div>
      <button onClick={() => makeReservation('sedan')}>Reserve Sedan</button>
      <button onClick={() => makeReservation('suv')}>Reserve SUV</button>
    </div>
  );
};

// A custom render function to wrap components with the provider
const renderWithProvider = (component: ReactNode) => {
  return render(<InventoryProvider>{component}</InventoryProvider>);
};

describe('InventoryContext', () => {
  test('1. should provide initial inventory counts (3 of each)', () => {
    renderWithProvider(<TestComponent />);

    expect(screen.getByTestId('sedan-count')).toHaveTextContent('3');
    expect(screen.getByTestId('suv-count')).toHaveTextContent('3');
    expect(screen.getByTestId('van-count')).toHaveTextContent('3');
  });

  test('2. should decrement inventory on a successful reservation', () => {
    renderWithProvider(<TestComponent />);

    // Check initial count
    expect(screen.getByTestId('sedan-count')).toHaveTextContent('3');

    // Make a reservation
    const reserveButton = screen.getByText('Reserve Sedan');
    fireEvent.click(reserveButton);

    // Check updated count
    expect(screen.getByTestId('sedan-count')).toHaveTextContent('2');
  });

  // ----- MODIFIED TEST CASE -----
  test('3. should throw an error when trying to reserve an unavailable vehicle', () => {
    // Suppress the expected console.error output from JSDOM.
    const consoleErrorSpy = jest
      .spyOn(console, 'error')
      .mockImplementation(() => {});

    renderWithProvider(<TestComponent />);

    const reserveButton = screen.getByText('Reserve SUV');

    // Reserve all available SUVs
    act(() => {
      fireEvent.click(reserveButton); // Count becomes 2
      fireEvent.click(reserveButton); // Count becomes 1
      fireEvent.click(reserveButton); // Count becomes 0
    });

    // Verify the count is zero before the final attempt
    expect(screen.getByTestId('suv-count')).toHaveTextContent('0');

    // Attempt to reserve one more time. We expect this to throw an error,
    // which will cause the component to unmount.
    expect(() => {
      fireEvent.click(reserveButton);
    }).toThrow('No SUVs available!');

    // The component has unmounted, so we cannot check the DOM anymore.
    // The .toThrow() assertion is sufficient to prove the logic works.
    // The inventory state itself would not be updated because the throw
    // happens before the state setter completes.

    // Restore the original console.error function
    consoleErrorSpy.mockRestore();
  });
  // ----- END OF MODIFIED TEST CASE -----

  test('4. should not affect other vehicle counts when making a reservation', () => {
    renderWithProvider(<TestComponent />);

    // Reserve a Sedan
    const reserveSedanButton = screen.getByText('Reserve Sedan');
    fireEvent.click(reserveSedanButton);

    // Assert that only the sedan count changed
    expect(screen.getByTestId('sedan-count')).toHaveTextContent('2');
    expect(screen.getByTestId('suv-count')).toHaveTextContent('3'); // Should be unchanged
    expect(screen.getByTestId('van-count')).toHaveTextContent('3'); // Should be unchanged
  });
});
