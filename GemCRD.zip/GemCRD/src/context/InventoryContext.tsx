// src/context/InventoryContext.tsx

import React, {
  createContext,
  useState,
  useContext,
  ReactNode,
  useCallback,
} from 'react';
import { Inventory, VehicleType } from '../types';

// Define the shape of the context data
interface InventoryContextType {
  inventory: Inventory;
  makeReservation: (vehicle: VehicleType) => void;
}

// Create the context with a default undefined value
// A runtime error will be thrown if used outside a provider
const InventoryContext = createContext<InventoryContextType | undefined>(
  undefined
);

// Define the initial state for our inventory
const INITIAL_INVENTORY: Inventory = {
  sedan: 3,
  suv: 3,
  van: 3,
};

// Create the Provider component
export const InventoryProvider = ({ children }: { children: ReactNode }) => {
  const [inventory, setInventory] = useState<Inventory>(INITIAL_INVENTORY);

  const makeReservation = useCallback((vehicle: VehicleType) => {
    setInventory((prevInventory) => {
      // Constraint: Check if vehicles are available
      if (prevInventory[vehicle] <= 0) {
        // Throw an error if no vehicles of the requested type are available
        throw new Error(`No ${vehicle.toUpperCase()}s available!`);
      }

      // Decrement the count for the reserved vehicle
      return {
        ...prevInventory,
        [vehicle]: prevInventory[vehicle] - 1,
      };
    });
  }, []);

  return (
    <InventoryContext.Provider value={{ inventory, makeReservation }}>
      {children}
    </InventoryContext.Provider>
  );
};

// Create a custom hook for easy access to the context
export const useInventory = () => {
  const context = useContext(InventoryContext);
  if (context === undefined) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
};
