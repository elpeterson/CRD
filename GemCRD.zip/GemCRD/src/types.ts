// src/types.ts

// Define the available vehicle types using a union type
export type VehicleType = 'sedan' | 'suv' | 'van';

// Create a constant array of vehicle types for easy mapping
export const VEHICLE_TYPES: VehicleType[] = ['sedan', 'suv', 'van'];

// Define the structure for our inventory state
export type Inventory = Record<VehicleType, number>;
